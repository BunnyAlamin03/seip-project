<?php
include_once 'library/applications.php';
$data = findone($_GET['id']);

if(array_key_exists('formdata', $_SESSION)){
//    $_SESSION['formdata'][$_GET['id']]= $_POST;
    $_SESSION['formdata'][$_POST[$data]]=$_POST;
    header('location:index.php');
}
?>