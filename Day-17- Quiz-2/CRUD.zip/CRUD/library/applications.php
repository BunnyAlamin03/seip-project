<?php
session_start();
include_once 'library/functions.php';
