<html>
    <head>
        <title>Crud Using Session</title>
    </head>
    <body>
        <div align="center" width="900">
          
            <legend><h3>Personal Info</h3></legend>
                <form action="process.php" method="post">
                <label>First Name</label>
                <input type="text" name="first_name" id="first_name">
                
                <label>Last Name</label>
                <input type="text" name="last_name" id="last_name">
                
                <label>Email</label>
                <input type="text" name="email" id="email">
                
                <label>Password</label>
                <input type="password" name="pw" id="pw">
                <input type="submit" value="Save">
                </form>
         
        </div>
    </body>
</html>