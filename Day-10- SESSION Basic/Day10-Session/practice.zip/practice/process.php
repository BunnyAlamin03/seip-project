<?php
include_once'./lib/applications.php';

if(array_key_exists('lastname', $_POST) && !empty($_POST['lastname'])){
    $_SESSION['mylstnames'][]= $_POST['lastname'];
    $msg = "New information has added";
    $_SESSION['message']= $msg;
    header('location: info.php');
}
else{
    $msg = "Please enter full info : ";
    $_SESSION['message']= $msg;
    header('location: info.php');
}


//for the first name 
if(array_key_exists('firstname', $_POST) && !empty($_POST['firstname'])){
    $_SESSION['myfstnames'][]= $_POST['firstname'];
    header('location: info.php');
}
else{
    $msg = "Please enter full info : ";
    $_SESSION['message']= $msg;
    header('location: info.php');
}




//for the first name 
if(array_key_exists('firstname', $_POST) && !empty($_POST['firstname'])){
    $_SESSION['mymidnames'][]= $_POST['middlename'];
    header('location: info.php');
}
else{
    $msg = "Please enter full info : ";
    $_SESSION['message']= $msg;
    header('location: info.php');
}
debug($_SESSION);
?>
<html>
    <head>
        <title>
            <?php echo PAGE_TITLE; ?>
        </title>
    </head>
</html>