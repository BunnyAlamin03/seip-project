<?php
session_start(); 
include_once 'functions.php';
include_once 'constants.php';
?>